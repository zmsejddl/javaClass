package chapter17.example;

public class Dog implements Soundable{

	@Override
	public String sound() {
		return "멍";
	}
	
}
