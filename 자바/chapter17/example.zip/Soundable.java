package chapter17.example;

public interface Soundable {
	String sound();
}
